

document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const storedUser = JSON.parse(localStorage.getItem("user"));

  if (!storedUser || storedUser.email !== email || storedUser.password !== password) {
    alert("Invalid credentials. Try again.");
    return;
  }

  alert(`Welcome back, ${storedUser.username}!`);
  window.location.href = "index.html"; // Redirect to home page
});

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('checkout-form');

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = form.elements['name'].value.trim();
    const email = form.elements['email'].value.trim();
    const address = form.elements['address'].value.trim();
    const payment = form.elements['payment'].value;

    if (!name || !email || !address || !payment) {
      alert('Please fill in all the fields.');
      return;
    }
    
    alert(`Thank you, ${name}! Your order has been placed.`);
    
    localStorage.removeItem('cart');
    
    window.location.href = 'index.html';
  });



