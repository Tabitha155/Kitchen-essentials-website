

document.addEventListener('DOMContentLoaded', function () {
  const addToCartBtn = document.querySelector('.add-to-cart-btn');
  
  addToCartBtn.addEventListener('click', function () {
    const product = {
      id: 1,
      name: document.querySelector('.product-detail-info h2').innerText,
      price: parseFloat(document.querySelector('.price').innerText.replace('Ksh', '').trim()),
      quantity: parseInt(document.querySelector('#quantity').value),
      image: document.querySelector('.product-detail-image img').src
    };
    
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    const existingItem = cart.find(item => item.id === product.id);
    if (existingItem) {
      existingItem.quantity += product.quantity;
    } else {
      
      cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));

    alert('Item added to cart!');
  });
  });

function loadCart() {
  const cartItems = JSON.parse(localStorage.getItem("cart")) || [];
  const cartItemsContainer= document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");
  cartItemsContainer.innerHTML = "";

  let total = 0;

  cartItems.forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const cartItem = document.createElement("div");
    cartItem.className = "cart-item";
    cartItem.innerHTML = `
      <img src="${item.image}" alt="${item.name}" />
      <div class="item-details">
        <h3>${item.name}</h3>
        <p>Price: Ksh ${item.price.toFixed(2)}</p>
        <p>Quantity: ${item.quantity}</p>
        <p>Total: Ksh ${itemTotal.toFixed(2)}</p>
      </div>
      <button class="remove-item" onclick="removeItem(${index})">Remove</button>
    `;
    cartItemsContainer.appendChild(cartItem);
  });

  cartTotal.textContent = total.toFixed(2);
}
  
function removeItem(index) {
  let cartItems = JSON.parse(localStorage.getItem("cart")) || [];
  cartItems.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cartItems));
  loadCart();
}


window.onload = loadCart;
  



